import threading
from protocol import Protocol
import json


class md_5_server:
    def __init__(self):
        self.Max_clients = 25
        self.client_cycle = 0
        self.counter = 0
        self.client_sock = None
        client_address = None
        self.server_socket = Protocol()
        # self.chunk = 9000000000 // self.Max_clients
        self.chunk = 90000000 // self.Max_clients

    def bind(self, ip, port):
        self.server_socket.bind((ip, port))

    def listen(self):
        self.server_socket.listen()
        print("Server is up and running")

    def accept(self):
        (self.client_sock, self.client_address) = self.server_socket.accept()
        print("[Server]: New Connection From: '%s:%s'" % (self.client_address[0], self.client_address[1]))
        self.client_cycle += 1
        self.client_sock.send_msg((json.dumps({"num": self.client_cycle, "chunk": self.chunk}).encode()))

    def found(self):
        found = False
        while not found:
            res = self.client_sock.get_msg().decode()
            print(res, "dagry mefager1")
            if "count" in res:
                print("in")
                # res = json.loads(res)
                # self.counter += res["count"]

            elif "done searching, not found " in res:
                print("done searching, not found")
                self.client_cycle += 1
                self.client_sock.send_msg((json.dumps({"num": self.client_cycle, "chunk": self.chunk}).encode()))

            elif "WE FOUND THE NUMER ITS " in res:
                print("found", self.client_address)
                self.client_sock.send_msg("close all".encode())


if __name__ == '__main__':
    server = md_5_server()
    server.bind("0.0.0.0", 8820)

    for i in range(server.Max_clients):
        server.listen()
        server.accept()
        threading.Thread(target=server.found, daemon=True).start()
